<?php 
class Murid {
	private $mysqli;

	function __construct($conn) {
		$this->mysqli = $conn;
	}

	public function tampil($id_murid = null){
		$db = $this->mysqli->conn;
		$sql= "SELECT *FROM murid";
		if($id_murid != null){
			$sql = "WHERE id = $id_murid";
		}
		$query = $db->query($sql) or die ($db->error);
		return $query;
	}

	public function tambah($id_murid, $nama_murid, $tempat_tgllahir, $jenjang_pendidikan, $alamat_rumah, $no_hp){
		$db = $this->mysqli->conn;
		$db->query("INSERT INTO murid VALUES ('$id_murid','$nama_murid', '$tempat_tgllahir', '$jenjang_pendidikan', '$alamat_rumah', '$no_hp')") or die ($db->error);
	}

	public function edit($sql){

		$db = $this->mysqli->conn;
	    $db->query($sql) or die ($db->error);

	}
}


 ?>