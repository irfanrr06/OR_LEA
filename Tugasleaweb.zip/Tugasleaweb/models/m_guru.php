<?php 
class Guru {
	private $mysqli;

	function __construct($conn) {
		$this->mysqli = $conn;
	}

	public function tampil($id_guru = null){
		$db = $this->mysqli->conn;
		$sql= "SELECT *FROM guru_les";
		if($id_guru != null){
			$sql = "WHERE id = $id_guru";
		}
		$query = $db->query($sql) or die ($db->error);
		return $query;
	}

	public function tambah($id_guru, $nama_guru, $tempat_tgllahir, $pend_terakhir, $mata_pelajaran, $jadwal_les, $honor, $no_hp, $foto){
		$db = $this->mysqli->conn;
		$db->query("INSERT INTO guru_les VALUES ('$id_guru','$nama_guru', '$tempat_tgllahir', '$pend_terakhir', '$mata_pelajaran', '$jadwal_les', '$honor', '$no_hp', '$foto')") or die ($db->error);
	}

	public function edit($sql){

		$db = $this->mysqli->conn;
	    $db->query($sql) or die ($db->error);

	}

	public function hapus($no_hp){
		$db = $this->mysqli->conn;
	    $db->query("DELETE FROM guru_les WHERE no_hp = '$no_hp'") or die ($db->error);

	}

	public function __destruct(){
	   		$db = $this->mysqli->conn;
	        $db->close();	
	}
}


 ?>