<?php 
require_once('../config/koneksi.php');
require_once('../models/database.php');
include "../models/m_murid.php";

$connection = new Database($host, $user, $pass, $database);
$murid = new Murid($connection);

$id_murid = $_POST['id_murid'];
$nama_murid = $connection->conn->real_escape_string($_POST['nama_murid']);
$tempat_tgllahir = $connection->conn->real_escape_string($_POST['tempat_tgllahir']);
$jenjang_pendidikan = $connection->conn->real_escape_string($_POST['jenjang_pendidikan']);
$alamat_rumah = $connection->conn->real_escape_string($_POST['alamat_rumah']);
$no_hp = $connection->conn->real_escape_string($_POST['no_hp']);


	$murid->edit("UPDATE murid SET id_murid = '$id_murid', nama_murid = '$nama_murid', tempat_tgllahir = '$tempat_tgllahir', jenjang_pendidikan = '$jenjang_pendidikan', alamat_rumah = '$alamat_rumah', no_hp='$no_hp' WHERE id_murid='$id_murid'");
	echo "<script>window.location='?page=murid';</script>";


 ?>
