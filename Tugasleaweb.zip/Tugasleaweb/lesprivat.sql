-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 13, 2020 at 06:48 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lesprivat`
--

-- --------------------------------------------------------

--
-- Table structure for table `guru_les`
--

CREATE TABLE `guru_les` (
  `id_guru` varchar(10) NOT NULL,
  `nama_guru` varchar(50) NOT NULL,
  `tempat_tgllahir` varchar(50) NOT NULL,
  `pend_terakhir` varchar(10) NOT NULL,
  `mata_pelajaran` varchar(50) NOT NULL,
  `jadwal_les` varchar(30) NOT NULL,
  `honor` varchar(20) NOT NULL,
  `no_hp` int(20) NOT NULL,
  `foto` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guru_les`
--

INSERT INTO `guru_les` (`id_guru`, `nama_guru`, `tempat_tgllahir`, `pend_terakhir`, `mata_pelajaran`, `jadwal_les`, `honor`, `no_hp`, `foto`) VALUES
('G01', 'Ridwan', 'Bukittinggi, 6 Desember 2004', 'S-1', 'Bahasa Indonesia', 'Jumat : 14.00 - 16.00', 'Rp2.500.000,-', 21623456, 'guru-1579917126.jfif'),
('G02', 'Danny', 'Jakarta,10 Juli 1987', 'S-3', 'Bahasa Inggris', 'Selasa : 14.55 - 16.00', 'Rp3.500.000,-', 21623459, 'guru-1581614345.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `murid`
--

CREATE TABLE `murid` (
  `id_murid` varchar(30) NOT NULL,
  `nama_murid` varchar(50) NOT NULL,
  `tempat_tgllahir` varchar(50) NOT NULL,
  `jenjang_pendidikan` varchar(10) NOT NULL,
  `alamat_rumah` varchar(50) NOT NULL,
  `no_hp` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `murid`
--

INSERT INTO `murid` (`id_murid`, `nama_murid`, `tempat_tgllahir`, `jenjang_pendidikan`, `alamat_rumah`, `no_hp`) VALUES
('M01', 'Irfan', 'Jakarta, 5 Mei 1999', 'SMA', 'Jl. Maju', 21123421),
('M02', 'ebbb', 'hgh6bb', 'SMA', 'Jl. Raya', 21623456),
('M04', 'Irfan Rahmat', 'Bukittinggi, 6 Desember 2000', 'Perguruan ', 'Polamas L2', 21123456);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `guru_les`
--
ALTER TABLE `guru_les`
  ADD PRIMARY KEY (`id_guru`);

--
-- Indexes for table `murid`
--
ALTER TABLE `murid`
  ADD PRIMARY KEY (`id_murid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
