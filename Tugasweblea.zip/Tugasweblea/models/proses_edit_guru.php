<?php 
require_once('../config/koneksi.php');
require_once('../models/database.php');
include "../models/m_guru.php";

$connection = new Database($host, $user, $pass, $database);
$guru = new Guru($connection);

$id_guru = $_POST['id_guru'];
$nama_guru = $connection->conn->real_escape_string($_POST['nama_guru']);
$tempat_tgllahir = $connection->conn->real_escape_string($_POST['tempat_tgllahir']);
$pend_terakhir = $connection->conn->real_escape_string($_POST['pend_terakhir']);
$mata_pelajaran = $connection->conn->real_escape_string($_POST['mata_pelajaran']);
$jadwal_les = $connection->conn->real_escape_string($_POST['jadwal_les']);
$honor = $connection->conn->real_escape_string($_POST['honor']);
$no_hp = $connection->conn->real_escape_string($_POST['no_hp']);

$pict = $_FILES['foto']['name'];
$ekstensi = explode(".",$_FILES['foto']['name']);
$foto = "guru-" . round(microtime(true))."." .end($ekstensi);
$sumber = $_FILES['foto']['tmp_name'];

if($pict == ''){
	$guru->edit("UPDATE guru_les SET id_guru = '$id_guru', nama_guru = '$nama_guru', tempat_tgllahir = '$tempat_tgllahir', pend_terakhir = '$pend_terakhir', mata_pelajaran = '$mata_pelajaran', jadwal_les='$jadwal_les', honor= '$honor', no_hp='$no_hp' WHERE id_guru='$id_guru'");
	echo "<script>window.location='?page=guru';</script>";

}else{
	$gbr_awal = $guru->tampil($id_guru)->fetch_object()->foto;
	unlink("../assets/img/guru/".$gbr_awal);

	
     $upload = move_uploaded_file($sumber, "../assets/img/guru/" .$foto);
	 if($upload){
     $guru->edit("UPDATE guru_les SET id_guru = '$id_guru', nama_guru = '$nama_guru', tempat_tgllahir = '$tempat_tgllahir', pend_terakhir = '$pend_terakhir', mata_pelajaran = '$mata_pelajaran', jadwal_les='$jadwal_les', honor= '$honor', no_hp='$no_hp', foto='$foto' WHERE id_guru='$id_guru'");
	echo "<script>window.location='?page=guru';</script>";
     }
     else{
     echo "<script>alert('Upload gambar gagal!')</script>";
     }


}
 ?>

