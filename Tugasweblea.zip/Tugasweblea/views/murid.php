<?php 
 include "models/m_murid.php";

 $murid = new Murid($connection);

  ?>

 <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="page-header">
                                Daftar Murid
                            </h2>
                            <!-- <ol class="breadcrumb">
                                <li>
                                    <i class="fa fa-plus"></i>  <a href="tambahguru.php">Tambah</a>
                                </li>
                               
                            </ol> -->
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover table-striped">
                                   <tr>
                                    <th>No.</th>
                                    <th>ID</th>
                                    <th>Nama Murid</th>
                                    <th>Tempat/Tgl Lahir</th>
                                    <th>Jenjang Pendidikan</th>
                                    <th>Alamat Rumah</th>
                                    <th>No.HP</th>
                                    <th>Opsi</th>
                                  </tr>
                                  <?php 
                                  $no = 1;
                                  $tampil = $murid->tampil();
                                  while ($data = $tampil -> fetch_object()) {
                                   ?>
                                  <tr>
                                      <td><?php echo $no++."."; ?></td>
                                      <td><?php echo $data->id_murid; ?></td>
                                      <td><?php echo $data->nama_murid; ?></td>
                                      <td><?php echo $data->tempat_tgllahir; ?></td>
                                      <td><?php echo $data->jenjang_pendidikan; ?></td>
                                      <td><?php echo $data->alamat_rumah; ?></td>
                                      <td><?php echo $data->no_hp; ?></td>
                                      <td>
                                        <a id="edit_murid" data-toggle="modal" data-target="#edit" data-id="<?php echo $data->id_murid; ?>"
                                            data-nama="<?php echo $data->nama_murid; ?>"
                                            data-ttl="<?php echo $data->tempat_tgllahir; ?>"
                                            data-jenjang_pendidikan="<?php echo $data->jenjang_pendidikan; ?>"
                                            data-alamat_rumah="<?php echo $data->alamat_rumah; ?>"
                                            data-hp="<?php echo $data->no_hp; ?>"
                                          <button class="btn btn-info btn-xl"> <i class="fa fa-edit"></i>Edit</button>
                                      </a>
                                          <button class="btn btn-danger btn-xl"> <i class="fa fa-trash-o"></i>Hapus</button>
                                      </td>


                                  </tr> 
                                  <?php 
                              }
                                   ?>
                                </table>
                            </div>
                            <button type="button" class="btn btn-success" data-toggle="modal" data-target="#tambah">Tambah Data</button>

                            <div id="tambah" class="modal fade" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title">Tambah Data Murid</h4>
                                        </div>
                                        <form action="" method="post" enctype="multipart/form-data">
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label class="control-label" for="id_murid">ID Murid</label>
                                                    <input type="text" name="id_murid" class="form-control" id="id_murid" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="nama_murid">Nama Murid</label>
                                                    <input type="text" name="nama_murid" class="form-control" id="nama_murid" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="tempat_tgllahir">Tempat,Tgl Lahir</label>
                                                    <input type="text" name="tempat_tgllahir" class="form-control" id="tempat_tgllahir" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="jenjang_pendidikan">Jenjang Pendidikan</label>
                                                    <input type="text" name="jenjang_pendidikan" class="form-control" id="jenjang_pendidikan" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="alamat_rumah">Alamat Rumah</label>
                                                    <input type="text" name="alamat_rumah" class="form-control" id="alamat_rumah" required>
                                                </div>
                                                
                                                <div class="form-group">
                                                    <label class="control-label" for="no_hp">No.HP</label>
                                                    <input type="text" name="no_hp" class="form-control" id="no_hp" required>
                                                </div>
                                               
                                            </div>
                                            <div class="modal-footer">
                                                <button type="reset" class= "btn btn-danger">Reset</button>
                                                <input type="submit" class= "btn btn-success" name="tambah" value="Simpan">
                                            </div>
                                        </form>
                                        <?php 

                                        if(@$_POST['tambah']){
                                            $id_murid = $connection->conn->real_escape_string($_POST['id_murid']);
                                            $nama_murid = $connection->conn->real_escape_string($_POST['nama_murid']);
                                            $tempat_tgllahir = $connection->conn->real_escape_string($_POST['tempat_tgllahir']);
                                            $jenjang_pendidikan = $connection->conn->real_escape_string($_POST['jenjang_pendidikan']);
                                            $alamat_rumah = $connection->conn->real_escape_string($_POST['alamat_rumah']);
                                            $no_hp = $connection->conn->real_escape_string($_POST['no_hp']);


                                            $murid-> tambah($id_murid, $nama_murid, $tempat_tgllahir, $jenjang_pendidikan, $alamat_rumah,$no_hp);
                                            header("location: ?page=murid");
                                            
                                          
                                        } ?>
                                        
                                    </div>
                                </div>
                            </div>

                             <div id="edit" class="modal fade" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title">Edit Data Murid</h4>
                                        </div>
                                        <form id="form" enctype="multipart/form-data">
                                            <div class="modal-body" id="modal-edit">
                                                <div class="form-group">
                                                    <label class="control-label" for="id_murid">ID Murid</label>
                                                    <input type="text" name="id_murid" class="form-control" id="id_murid" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="nama_murid">Nama Murid</label>
                                                    <input type="hidden" name="id_murid" id="id_murid">
                                                    <input type="text" name="nama_murid" class="form-control" id="nama_murid" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="tempat_tgllahir">Tempat,Tgl Lahir</label>
                                                    <input type="text" name="tempat_tgllahir" class="form-control" id="tempat_tgllahir" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="jenjang_pendidikan">Jenjang Pendidikan</label>
                                                    <input type="text" name="jenjang_pendidikan" class="form-control" id="jenjang_pendidikan" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="alamat_rumah">Alamat Rumah</label>
                                                    <input type="text" name="alamat_rumah" class="form-control" id="alamat_rumah" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="no_hp">No.HP</label>
                                                    <input type="text" name="no_hp" class="form-control" id="no_hp" required>
                                                </div>
                                               
                                            <div class="modal-footer">
                                                <input type="submit" class= "btn btn-success" name="edit" value="Simpan">
                                            </div>
                                        </form>
                
                                        
                                    </div>
                                </div>
                            </div>

                            <script src="assets/js/jquery.js"></script>
                            <script type="text/javascript">
                                
                                $(document).on("click", "#edit_murid", function(){
                                    var id_murid = $(this).data('id');
                                    var nama_murid = $(this).data('nama');
                                    var tempat_tgllahir = $(this).data('ttl');
                                    var jenjang_pendidikan = $(this).data('jenjang_pendidikan');
                                    var alamat_rumah = $(this).data('alamat_rumah');
                                    var no_hp = $(this).data('hp');
                                    $("#modal-edit #id_murid").val(id_murid);
                                    $("#modal-edit #nama_murid").val(nama_murid);
                                    $("#modal-edit #tempat_tgllahir").val(tempat_tgllahir);
                                    $("#modal-edit #jenjang_pendidikan").val(jenjang_pendidikan);
                                    $("#modal-edit #alamat_rumah").val(alamat_rumah);
                                    $("#modal-edit #no_hp").val(no_hp);
                                })

                                $(document).ready(function(e){
                                    $("#form").on("submit", (function(e){
                                        e.preventDefault();
                                        $.ajax({
                                            url : 'models/proses_edit_murid.php',
                                            type : 'POST',
                                            data : new FormData(this),
                                            contentType : false,
                                            cache : false,
                                            processData : false,
                                            success : function(msg){
                                                $('.table').html(msg);
                                            }
                                        });
                                    }));
                                })

                                        
                                    
                            
                            </script>

                        </div>
                    </div>