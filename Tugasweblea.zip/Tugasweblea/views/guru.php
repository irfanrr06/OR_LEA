 <?php 
 include "models/m_guru.php";

 $guru = new Guru($connection);

 if(@$_GET['act'] == '') {
  ?>

 <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="page-header">
                                Daftar Guru Les
                            </h2>
                            <!-- <ol class="breadcrumb">
                                <li>
                                    <i class="fa fa-plus"></i>  <a href="tambahguru.php">Tambah</a>
                                </li>
                               
                            </ol> -->
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover table-striped">
                                   <tr>
                                    <th>No.</th>
                                    <th>ID</th>
                                    <th>Nama Guru</th>
                                    <th>Tempat/Tgl Lahir</th>
                                    <th>Pendidikan Terakhir</th>
                                    <th>Mata Pelajaran</th>
                                    <th>Jadwal Les</th>
                                    <th>Honor</th>
                                    <th>No.HP</th>
                                    <th>Foto</th>
                                    <th>Opsi</th>
                                  </tr>
                                  <?php 
                                  $no = 1;
                                  $tampil = $guru->tampil();
                                  while ($data = $tampil -> fetch_object()) {
                                   ?>
                                  <tr>
                                      <td><?php echo $no++."."; ?></td>
                                      <td><?php echo $data->id_guru; ?></td>
                                      <td><?php echo $data->nama_guru; ?></td>
                                      <td><?php echo $data->tempat_tgllahir; ?></td>
                                      <td><?php echo $data->pend_terakhir; ?></td>
                                      <td><?php echo $data->mata_pelajaran; ?></td>
                                      <td><?php echo $data->jadwal_les; ?></td>
                                      <td><?php echo $data->honor; ?></td>
                                      <td><?php echo $data->no_hp; ?></td>
                                      <td>
                                        <img src="assets/img/guru/<?php echo $data->foto; ?>" width="70px">
                                      </td>
                                      <td>
                                        <a id="edit_guru" data-toggle="modal" data-target="#edit" data-id="<?php echo $data->id_guru; ?>"
                                            data-nama="<?php echo $data->nama_guru; ?>"
                                            data-ttl="<?php echo $data->tempat_tgllahir; ?>"
                                            data-pend_terakhir="<?php echo $data->pend_terakhir; ?>"
                                            data-mapel="<?php echo $data->mata_pelajaran; ?>"
                                            data-jadwal="<?php echo $data->jadwal_les; ?>"
                                            data-honor="<?php echo $data->honor; ?>"
                                            data-hp="<?php echo $data->no_hp; ?>"
                                            data-foto="<?php echo $data->foto; ?>">
                                          <button class="btn btn-info btn-xl"> <i class="fa fa-edit"></i>Edit</button>
                                      </a>
                                      <a href="?page=guru&act=del&id=<?php echo $data->no_hp; ?>" onclick="return confirm ('Anda Yakin?')">
                                          <button class="btn btn-danger btn-xl"> <i class="fa fa-trash-o"></i>Hapus</button>
                                    </a>
                                      </td>


                                  </tr> 
                                  <?php 
                              }
                                   ?>
                                </table>
                            </div>
                            <button type="button" class="btn btn-success" data-toggle="modal" data-target="#tambah">Tambah Data</button>

                            <div id="tambah" class="modal fade" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title">Tambah Data Guru</h4>
                                        </div>
                                        <form action="" method="post" enctype="multipart/form-data">
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label class="control-label" for="id_guru">ID Guru</label>
                                                    <input type="text" name="id_guru" class="form-control" id="id_guru" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="nama_guru">Nama Guru</label>
                                                    <input type="text" name="nama_guru" class="form-control" id="nama_guru" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="tempat_tgllahir">Tempat,Tgl Lahir</label>
                                                    <input type="text" name="tempat_tgllahir" class="form-control" id="tempat_tgllahir" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="pend_terakhir">Pendidikan Terakhir</label>
                                                    <input type="text" name="pend_terakhir" class="form-control" id="pend_terakhir" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="mata_pelajaran">Mata Pelajaran</label>
                                                    <input type="text" name="mata_pelajaran" class="form-control" id="mata_pelajaran" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="jadwal_les">Jadwal Les</label>
                                                    <input type="text" name="jadwal_les" class="form-control" id="jadwal_les" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="honor">Honor</label>
                                                    <input type="text" name="honor" class="form-control" id="honor" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="no_hp">No.HP</label>
                                                    <input type="text" name="no_hp" class="form-control" id="no_hp" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="foto">Foto</label>
                                                    <input type="file" name="foto" class="form-control" id="foto" required>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="reset" class= "btn btn-danger">Reset</button>
                                                <input type="submit" class= "btn btn-success" name="tambah" value="Simpan">
                                            </div>
                                        </form>
                                        <?php 

                                        if(@$_POST['tambah']){
                                            $id_guru = $connection->conn->real_escape_string($_POST['id_guru']);
                                            $nama_guru = $connection->conn->real_escape_string($_POST['nama_guru']);
                                            $tempat_tgllahir = $connection->conn->real_escape_string($_POST['tempat_tgllahir']);
                                            $pend_terakhir = $connection->conn->real_escape_string($_POST['pend_terakhir']);
                                            $mata_pelajaran = $connection->conn->real_escape_string($_POST['mata_pelajaran']);
                                            $jadwal_les = $connection->conn->real_escape_string($_POST['jadwal_les']);
                                            $honor = $connection->conn->real_escape_string($_POST['honor']);
                                            $no_hp = $connection->conn->real_escape_string($_POST['no_hp']);

                                            $ekstensi = explode(".",$_FILES['foto']['name']);
                                            $foto = "guru-" . round(microtime(true))."." .end($ekstensi);
                                            $sumber = $_FILES['foto']['tmp_name'];
                                            $upload = move_uploaded_file($sumber, "assets/img/guru/" .$foto);

                                            if($upload){
                                                $guru-> tambah($id_guru, $nama_guru, $tempat_tgllahir, $pend_terakhir, $mata_pelajaran, $jadwal_les, $honor, $no_hp, $foto);
                                                header("location: ?page=guru");
                                            }
                                            else{
                                                echo "<script>alert('Upload gambar gagal!')</script>";
                                            }
                                        } ?>
                                        
                                    </div>
                                </div>
                            </div>

                             <div id="edit" class="modal fade" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title">Edit Data Guru</h4>
                                        </div>
                                        <form id="form" enctype="multipart/form-data">
                                            <div class="modal-body" id="modal-edit">
                                                <div class="form-group">
                                                    <label class="control-label" for="id_guru">ID Guru</label>
                                                    <input type="text" name="id_guru" class="form-control" id="id_guru" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="nama_guru">Nama Guru</label>
                                                    <input type="hidden" name="id_guru" id="id_guru">
                                                    <input type="text" name="nama_guru" class="form-control" id="nama_guru" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="tempat_tgllahir">Tempat,Tgl Lahir</label>
                                                    <input type="text" name="tempat_tgllahir" class="form-control" id="tempat_tgllahir" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="pend_terakhir">Pendidikan Terakhir</label>
                                                    <input type="text" name="pend_terakhir" class="form-control" id="pend_terakhir" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="mata_pelajaran">Mata Pelajaran</label>
                                                    <input type="text" name="mata_pelajaran" class="form-control" id="mata_pelajaran" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="jadwal_les">Jadwal Les</label>
                                                    <input type="text" name="jadwal_les" class="form-control" id="jadwal_les" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="honor">Honor</label>
                                                    <input type="text" name="honor" class="form-control" id="honor" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="no_hp">No.HP</label>
                                                    <input type="text" name="no_hp" class="form-control" id="no_hp" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label" for="foto">Foto</label>
                                                    <div style="padding-bottom: 5px">
                                                        <img src="" width="80px" id="pict">
                                                    </div>
                                                    <input type="file" name="foto" class="form-control" id="foto">
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <input type="submit" class= "btn btn-success" name="edit" value="Simpan">
                                            </div>
                                        </form>
                
                                        
                                    </div>
                                </div>
                            </div>

                            <script src="assets/js/jquery.js"></script>
                            <script type="text/javascript">
                                
                                $(document).on("click", "#edit_guru", function(){
                                    var id_guru = $(this).data('id');
                                    var nama_guru = $(this).data('nama');
                                    var tempat_tgllahir = $(this).data('ttl');
                                    var pend_terakhir = $(this).data('pend_terakhir');
                                    var mata_pelajaran = $(this).data('mapel');
                                    var jadwal_les = $(this).data('jadwal');
                                    var honor = $(this).data('honor');
                                    var no_hp = $(this).data('hp');
                                    var foto = $(this).data('foto');
                                    $("#modal-edit #id_guru").val(id_guru);
                                    $("#modal-edit #nama_guru").val(nama_guru);
                                    $("#modal-edit #tempat_tgllahir").val(tempat_tgllahir);
                                    $("#modal-edit #pend_terakhir").val(pend_terakhir);
                                    $("#modal-edit #mata_pelajaran").val(mata_pelajaran);
                                    $("#modal-edit #jadwal_les").val(jadwal_les);
                                    $("#modal-edit #honor").val(honor);
                                    $("#modal-edit #no_hp").val(no_hp);
                                    $("#modal-edit #pict").attr("src", "assets/img/guru/"+foto);
                                })

                                $(document).ready(function(e){
                                    $("#form").on("submit", (function(e){
                                        e.preventDefault();
                                        $.ajax({
                                            url : 'models/proses_edit_guru.php',
                                            type : 'POST',
                                            data : new FormData(this),
                                            contentType : false,
                                            cache : false,
                                            processData : false,
                                            success : function(msg){
                                                $('.table').html(msg);
                                            }
                                        });
                                    }));
                                })

                                        
                                    
                            
                            </script>

                        </div>
                    </div>
                    <?php 
}else if(@$_GET['act'] == 'del'){
    $gbr_awal = $guru->tampil($_GET['no_hp'])->fetch_object()->foto;
    unlink("assets/img/guru/".$gbr_awal);

    $guru->hapus($_GET['id']);
    header("location: ?page=guru");
}


                     ?>